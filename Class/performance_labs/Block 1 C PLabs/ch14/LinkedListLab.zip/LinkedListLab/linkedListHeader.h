#include <stdio.h>

extern int printMenu();
extern void printAllInfo(node_t *head);
void printSpecificInfo(node_t *head, int userChoice);
void printSpecificStudent(node_t *desiredNode);